package pe.egcc.app.prueba;

import pe.egcc.app.service.Clase2;
import pe.egcc.app.service.Clase3;

/**
 *
 * @author Gustavo Coronel
 * @blog   gcoronelc.blogspot.com
 * @email  gcoronelc@gmail.com
 */
public class Prueba04 {
  
  public static void main(String[] args) {
    
    Clase2 clase2 = new Clase3();
    
    System.out.println("9 + 4 = " + clase2.sumar(9, 4));
    
    
  }

}
