package pe.egcc.app.service;

/**
 *
 * @author Gustavo Coronel
 * @blog   gcoronelc.blogspot.com
 * @email  gcoronelc@gmail.com
 */
public class Clase1 {

  public Clase1() {
    System.out.println("Hola Gustavo.");
  }
  
  public Clase1(String nombre) {
    System.out.println("Hola " + nombre + ".");
  }

  public int sumar(int n1, int n2){
    return (n1 + n2);
  }

}
