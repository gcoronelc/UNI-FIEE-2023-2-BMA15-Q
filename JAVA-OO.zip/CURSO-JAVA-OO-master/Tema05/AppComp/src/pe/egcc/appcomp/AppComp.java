package pe.egcc.appcomp;

import pe.egcc.appcomp.view.VentaView;

/**
 *
 * @author Gustavo Coronel
 * @blog   gcoronelc.blogspot.com
 * @email  gcoronelc@gmail.com
 */
public class AppComp {

    public static void main(String[] args) {
        VentaView.main(args);
    }

}
