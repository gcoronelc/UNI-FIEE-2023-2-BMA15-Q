package pe.egcc.app.pruebas;

/**
 *
 * @author Gustavo Coronel
 * @blog   gcoronelc.blogspot.com
 * @email  gcoronelc@gmail.com
 */
public class Prueba01 {

   public static void main(String[] args) {
      // Datos
      int n1 = 30;
      int n2 = 0;
      // Proceso
      int n3 = n1 / n2;
      // Reporte
      System.out.println("n1: " + n1);
      System.out.println("n2: " + n2);
      System.out.println("n3: " + n3);   
   }
   
}
