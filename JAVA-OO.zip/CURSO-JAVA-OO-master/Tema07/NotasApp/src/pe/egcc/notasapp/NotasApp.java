package pe.egcc.notasapp;

import pe.egcc.notasapp.view.NotasView;

/**
 *
 * @author Gustavo Coronel
 * @blog   gcoronelc.blogspot.com
 * @email  gcoronelc@gmail.com
 */
public class NotasApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        NotasView.main(args);
    }

}
