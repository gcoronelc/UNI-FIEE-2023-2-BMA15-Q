package pe.egcc.app.prueba;

/**
 *
 * @author Gustavo Coronel
 * @blog   gcoronelc.blogspot.com
 * @email  gcoronelc@gmail.com
 */
public class Prueba01 {
  
  public static void main(String[] args) {
    
    System.out.println("Mayor: " + Math.max(15, 18));
    System.out.println("Menor: " + Math.min(15, 18));
  }

}
