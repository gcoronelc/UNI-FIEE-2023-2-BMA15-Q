package pe.edutec.promedioapp;

import pe.edutec.promedioapp.view.PromedioView;

/**
 *
 * @author Gustavo Coronel
 * @blog   gcoronelc.blogspot.com
 * @email  gcoronelc@gmail.com
 */
public class PromedioApp {

  public static void main(String[] args) {
    PromedioView.main(args);
  }
  
}
