package pe.egcc.pagoapp;

import pe.egcc.pagoapp.view.PagoView;

/**
 *
 * @author Eric Gustavo Coronel Castillo
 * @blog   www.desarrollasoftware.com
 * @email  gcoronelc@gmail.com
 */
public class ClasePrincipal {

    public static void main(String[] args) {
        PagoView.main(null);
    }

}
