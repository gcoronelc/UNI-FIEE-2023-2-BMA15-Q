package pe.egcc.prueba;

import pe.egcc.service.ClaseServicios;

/**
 *
 * @author Eric Gustavo Coronel Castillo
 * @blog   www.desarrollasoftware.com
 * @email  gcoronelc@gmail.com
 */
public class Prueba05 extends ClaseServicios{
  
  public static void main(String[] args) {
    Prueba05 bean = new Prueba05();
    bean.metodo3();
    bean.metodo4();
  }

}
