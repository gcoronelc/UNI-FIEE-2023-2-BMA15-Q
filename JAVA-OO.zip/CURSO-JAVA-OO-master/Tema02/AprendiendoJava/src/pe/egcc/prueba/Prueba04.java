package pe.egcc.prueba;

import pe.egcc.dos.ClaseC;
import pe.egcc.dos.ClaseD;

/**
 *
 * @author Eric Gustavo Coronel Castillo
 * @blog   www.desarrollasoftware.com
 * @email  gcoronelc@gmail.com
 */
public class Prueba04 {

  public static void main(String[] args) {
    ClaseD bean = new ClaseD();
    bean.metodoD();
  }
}
