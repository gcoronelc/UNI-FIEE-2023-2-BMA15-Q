package pe.egcc.prueba;

import pe.egcc.modelo.Articulo;

/**
 *
 * @author Eric Gustavo Coronel Castillo
 * @blog   www.desarrollasoftware.com
 * @email  gcoronelc@gmail.com
 */
public class Prueba08 {
  
  public static void main(String[] args) {
    while(true){
      new Articulo();
    }
  }

}
