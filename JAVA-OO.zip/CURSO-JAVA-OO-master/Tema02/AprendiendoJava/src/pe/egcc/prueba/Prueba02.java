package pe.egcc.prueba;

import pe.egcc.uno.ClaseB;

/**
 *
 * @author Eric Gustavo Coronel Castillo
 * @blog   www.desarrollasoftware.com
 * @email  gcoronelc@gmail.com
 */
public class Prueba02 {

  public static void main(String[] args) {
    ClaseB bean = new ClaseB();
    bean.metodoB();
  }
}
