package pe.egcc.prueba;

import pe.egcc.service.ClaseServicios;

/**
 *
 * @author Eric Gustavo Coronel Castillo
 * @blog   www.desarrollasoftware.com
 * @email  gcoronelc@gmail.com
 */
public class Prueba06 {
  
  public static void main(String[] args) {
    ClaseServicios servicios = new ClaseServicios();
    servicios.metodo4();
  }

}
