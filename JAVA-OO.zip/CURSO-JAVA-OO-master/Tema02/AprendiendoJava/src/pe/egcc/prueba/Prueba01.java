package pe.egcc.prueba;

import pe.egcc.uno.ClaseA;

/**
 *
 * @author Eric Gustavo Coronel Castillo
 * @blog   www.desarrollasoftware.com
 * @email  gcoronelc@gmail.com
 */
public class Prueba01 {
  
  public static void main(String[] args) {
    ClaseA bean = new ClaseA();
    bean.metodoA();
  }

}
