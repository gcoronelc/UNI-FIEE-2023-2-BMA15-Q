package pe.egcc.prueba;

import pe.egcc.dos.ClaseC;

/**
 *
 * @author Eric Gustavo Coronel Castillo
 * @blog   www.desarrollasoftware.com
 * @email  gcoronelc@gmail.com
 */
public class Prueba03 {
  
  public static void main(String[] args) {
    ClaseC bean = new ClaseC();
    bean.metodoC();
  }

}
