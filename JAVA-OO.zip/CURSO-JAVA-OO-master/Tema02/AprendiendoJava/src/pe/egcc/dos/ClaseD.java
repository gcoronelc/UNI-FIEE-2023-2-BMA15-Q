package pe.egcc.dos;

import pe.egcc.uno.ClaseA;

/**
 *
 * @author Eric Gustavo Coronel Castillo
 * @blog www.desarrollasoftware.com
 * @email gcoronelc@gmail.com
 */
public class ClaseD {

  public void metodoD() {
    ClaseA bean = new ClaseA();
    //System.out.println("n1: " + bean.n1);
    //System.out.println("n2: " + bean.n2);
    //System.out.println("n3: " + bean.n3);
    System.out.println("n4: " + bean.n4);
  }

}
