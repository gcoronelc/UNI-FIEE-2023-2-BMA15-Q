package pe.egcc.service;

/**
 *
 * @author Eric Gustavo Coronel Castillo
 * @blog   www.desarrollasoftware.com
 * @email  gcoronelc@gmail.com
 */
public class Probando01 {

  public static void main(String[] args) {
    ClaseServicios servicios = new ClaseServicios();
    servicios.metodo2();
    servicios.metodo3();
    servicios.metodo4();
  }
}
