package pe.egcc.cambioapp;

import pe.egcc.cambioapp.view.CambioView;

/**
 *
 * @author Gustavo Coronel
 * @blog   gcoronelc.blogspot.com
 * @email  gcoronelc@gmail.com
 */
public class CambioApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CambioView.main(args);
    }

}
