package pe.egcc.app.spec;

/**
 *
 * @author Gustavo Coronel
 * @blog   gcoronelc.blogspot.com
 * @email  gcoronelc@gmail.com
 */
public interface MantenimientoSpec {

   void insertar();
   void modificar();
   void eliminar();
   
}
