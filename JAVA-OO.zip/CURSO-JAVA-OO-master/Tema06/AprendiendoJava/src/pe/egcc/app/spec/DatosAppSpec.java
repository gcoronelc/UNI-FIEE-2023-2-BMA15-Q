package pe.egcc.app.spec;

/**
 *
 * @author Gustavo Coronel
 * @blog   gcoronelc.blogspot.com
 * @email  gcoronelc@gmail.com
 */
public interface DatosAppSpec {
   
   // Operaciones CRUD
   String CRUD_NEW = "NUEVO";
   String CRUD_EDIT = "EDITAR";
   String CRUD_DELETE = "ELIMINAR";
   
   

}
