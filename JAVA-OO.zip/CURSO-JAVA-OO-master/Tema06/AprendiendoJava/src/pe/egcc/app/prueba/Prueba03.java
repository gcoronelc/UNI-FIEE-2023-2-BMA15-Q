package pe.egcc.app.prueba;

import pe.egcc.app.spec.DatosAppSpec;

/**
 *
 * @author Gustavo Coronel
 * @blog   gcoronelc.blogspot.com
 * @email  gcoronelc@gmail.com
 */
public class Prueba03 {

   public static void main(String[] args) {
      
      System.out.println(DatosAppSpec.CRUD_NEW);
      
   }
}
