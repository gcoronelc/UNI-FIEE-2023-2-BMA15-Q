package pe.egcc.service;

/**
 *
 * @author Eric Gustavo Coronel Castillo
 * @blog   www.desarrollasoftware.com
 * @email  gcoronelc@gmail.com
 */
public class MateService {
  
  public int sumar(int n1, int n2){
    int suma;
    suma = n1 + n2;
    return suma;
  }

}
