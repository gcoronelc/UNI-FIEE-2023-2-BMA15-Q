package pe.egcc.modelo;

/**
 *
 * @author Eric Gustavo Coronel Castillo
 * @blog   www.desarrollasoftware.com
 * @email  gcoronelc@gmail.com
 */
public class Articulo {
  
  // Variables
  private String nombre;
  private double precio;
  private int stock;
  
  
  

}

