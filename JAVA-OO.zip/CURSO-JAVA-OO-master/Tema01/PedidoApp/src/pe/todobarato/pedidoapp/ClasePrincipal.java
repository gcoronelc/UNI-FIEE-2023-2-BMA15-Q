package pe.todobarato.pedidoapp;

import pe.todobarato.pedidoapp.layer.view.PedidoView;

/**
 *
 * @author Eric Gustavo Coronel Castillo
 * @blog   www.desarrollasoftware.com
 * @email  gcoronelc@gmail.com
 */
public class ClasePrincipal {

    public static void main(String[] args) {
        PedidoView.main(null);
    }

}
