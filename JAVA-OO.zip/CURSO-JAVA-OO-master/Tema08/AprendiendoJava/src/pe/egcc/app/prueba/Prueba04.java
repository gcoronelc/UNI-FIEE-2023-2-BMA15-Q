package pe.egcc.app.prueba;

/**
 *
 * @author Gustavo Coronel
 * @blog   gcoronelc.blogspot.com
 * @email  gcoronelc@gmail.com
 */
public class Prueba04 {

   public static void main(String[] args) {
      
      // Caso 1
      int[] vector;
      vector = new int[10];
      
      // Caso 2
      int[] vector2 = new int[20];
      
      // Caso 3
      int vector3[] = {43,21,34,12,89,54};
      
      // Caso 4
      int vector4[];
      vector4 = new int[]{87,23,45,76,23};
      
   }
}
