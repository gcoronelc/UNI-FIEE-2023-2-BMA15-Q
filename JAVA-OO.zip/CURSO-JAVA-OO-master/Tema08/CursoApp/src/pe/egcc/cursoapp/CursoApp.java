package pe.egcc.cursoapp;

import pe.egcc.cursoapp.view.RegistroView;

/**
 *
 * @author Gustavo Coronel
 * @blog   gcoronelc.blogspot.com
 * @email  gcoronelc@gmail.com
 */
public class CursoApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        RegistroView.main(args);
    }

}
